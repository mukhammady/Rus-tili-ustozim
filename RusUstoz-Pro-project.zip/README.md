# RusUstoz Pro (Android)

Premium-style Kotlin + Jetpack Compose Android learning app for Uzbek speakers learning practical Russian for advertising/printing customer service.

## Included in this project
- Home, lessons, AI Ustoz demo, vocabulary, and profile tabs.
- 10 modules × 10 lesson titles (100 lessons generated from reusable lesson data).
- Each generated lesson includes 30 phrase cards, 3 practical dialogue sections (8 turns each; 24 turns total), and 15 multiple-choice exercises.
- Russian TextToSpeech playback and optional Russian speech recognition.
- Progress completion while using the app. This starter currently does not persist all progress across restarts.
- AI Ustoz is clearly marked as demo mode; it is not connected to a real AI backend. Do not enter API keys into the Android app.

## Build using GitHub from a phone
1. Upload `RusUstoz-Pro-project.zip` to the root of your GitHub repository.
2. Upload the provided `android-apk-rusustoz-pro.yml` as `.github/workflows/android-apk-rusustoz-pro.yml` (create folders if needed).
3. Open the repository's **Actions** tab.
4. Choose **Build RusUstoz Pro APK** and tap **Run workflow**, or push a commit to the main branch.
5. When the run succeeds, open it and download the `RusUstoz-Pro-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install the `.apk` on your Android phone.

## Important limitations
- This source has not been compiled in this environment because an Android SDK/Gradle installation is not available here. Use GitHub Actions to verify the build.
- AI Teacher currently runs in demo mode. A real AI teacher requires a separate secure backend; keep API keys on the server, not in the APK.
- The current progress implementation is not yet persisted after app restart.
