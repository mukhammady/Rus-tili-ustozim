package uz.rusustoz.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF17243A)
private val Blue = Color(0xFF2457D6)
private val Sky = Color(0xFFEAF0FF)
private val Light = lightColorScheme(
    primary = Blue, onPrimary = Color.White, primaryContainer = Sky, onPrimaryContainer = Ink,
    secondary = Color(0xFF0E8A78), background = Color(0xFFF7F8FC), surface = Color.White,
    surfaceVariant = Color(0xFFF0F3FA), onSurface = Ink, onSurfaceVariant = Color(0xFF596579),
    error = Color(0xFFB42318), errorContainer = Color(0xFFFFE8E5)
)
private val Dark = darkColorScheme(
    primary = Color(0xFF9BB5FF), primaryContainer = Color(0xFF253B70), secondary = Color(0xFF71D8C5),
    background = Color(0xFF0E1420), surface = Color(0xFF171F2D), surfaceVariant = Color(0xFF222D40),
    onSurface = Color(0xFFF0F3FA), onSurfaceVariant = Color(0xFFB6C0D2)
)
private val RusTypography = Typography(
    headlineLarge = androidx.compose.ui.text.TextStyle(fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp),
    headlineMedium = androidx.compose.ui.text.TextStyle(fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
    titleLarge = androidx.compose.ui.text.TextStyle(fontSize = 21.sp, fontWeight = FontWeight.Bold),
    titleMedium = androidx.compose.ui.text.TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = androidx.compose.ui.text.TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 21.sp)
)

@Composable
fun RusUstozTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = RusTypography, content = content)
}
