package uz.rusustoz.app.ui

import android.speech.tts.TextToSpeech
import android.content.Intent
import android.speech.RecognizerIntent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import androidx.compose.ui.graphics.vector.ImageVector
import uz.rusustoz.app.ui.screens.PlaceholderScreen
import java.util.Locale

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Bosh sahifa", Icons.Filled.Home),
    Lessons("lessons", "Darslar", Icons.Filled.Book),
    Teacher("teacher", "AI Ustoz", Icons.Filled.Chat),
    Words("words", "Lug‘at", Icons.Filled.Translate),
    Profile("profile", "Profil", Icons.Filled.AccountCircle),
}

private data class Phrase(val ru: String, val uz: String, val pron: String)
private data class DialogueLine(val speaker: String, val ru: String, val uz: String)
private data class Exercise(val question: String, val answers: List<String>, val correct: Int, val explanation: String)
private data class Lesson(val id: String, val module: Int, val moduleTitle: String, val title: String, val goal: String, val phrases: List<Phrase>, val dialogue: List<DialogueLine>, val exercises: List<Exercise>)

private data class LessonSpec(val title: String, val goal: String)
private val moduleData = listOf(
    Triple("Kirish va kundalik muloqot", listOf(LessonSpec("Salomlashish", "Suhbatni xushmuomala boshlash"), LessonSpec("O‘zingizni tanishtirish", "Ismingiz va vazifangizni aytish"), LessonSpec("Iltimos va rahmat", "Muloyim iboralarni ishlatish"), LessonSpec("Suhbatni yakunlash", "Suhbatni odob bilan tugatish"), LessonSpec("Hol-ahvol so‘rash", "Oddiy savol-javob qilish"), LessonSpec("Tanishuv savollari", "Suhbatdosh haqida so‘rash"), LessonSpec("Kechirim so‘rash", "Noqulay vaziyatda uzr aytish"), LessonSpec("Tushunmaganini aytish", "Qayta tushuntirishni so‘rash"), LessonSpec("Sekinroq gapirishni so‘rash", "Nutq tezligini aniqlashtirish"), LessonSpec("Xayrlashish", "Xayrlashuv iboralarini ishlatish")), listOf(Phrase("Здравствуйте!","Assalomu alaykum! (rasmiy)","Zdravstvuyte"), Phrase("Доброе утро!","Xayrli tong!","Dobroye utro"), Phrase("Меня зовут ...","Mening ismim ...","Menya zavut"), Phrase("Очень приятно.","Tanishganimdan xursandman.","Ochen priyatno"), Phrase("Спасибо большое.","Katta rahmat.","Spasiba balshoye"), Phrase("Пожалуйста.","Iltimos / marhamat.","Pazhalusta"), Phrase("Извините, пожалуйста.","Kechirasiz, iltimos.","Izvinite pazhalusta"), Phrase("Повторите, пожалуйста.","Iltimos, qaytaring.","Pavtarite pazhalusta"), Phrase("Говорите немного медленнее.","Biroz sekinroq gapiring.","Gavarite nemnoga medlenneye"), Phrase("До свидания!","Xayr! (rasmiy)","Da svidaniya"))),
    Triple("Do‘kon va kundalik xizmatlar", listOf(LessonSpec("Do‘konda xarid", "Kerakli mahsulotni so‘rash"), LessonSpec("Narxni so‘rash", "Mahsulot narxini bilish"), LessonSpec("Miqdor va son", "Miqdorni aniqlash"), LessonSpec("Rang va o‘lcham", "Variantlarni tanlash"), LessonSpec("To‘lov usuli", "To‘lov haqida gaplashish"), LessonSpec("Chek so‘rash", "Xarid chekini so‘rash"), LessonSpec("Mahsulot mavjudligi", "Bor-yo‘qligini so‘rash"), LessonSpec("Almashtirish", "Mahsulotni almashtirish haqida so‘rash"), LessonSpec("Yetkazib berish", "Yetkazib berish shartlarini bilish"), LessonSpec("Shikoyat bildirish", "Muammoni xushmuomala tushuntirish")), listOf(Phrase("Сколько это стоит?","Bu qancha turadi?","Skolka eta stoit"), Phrase("У вас это есть?","Sizda bu bormi?","U vas eta yest"), Phrase("Мне нужно два.","Menga ikkitasi kerak.","Mne nuzhna dva"), Phrase("Есть другой размер?","Boshqa o‘lchami bormi?","Yest drugoy razmer"), Phrase("Можно оплатить картой?","Karta bilan to‘lash mumkinmi?","Mozhna oplatit kartoy"), Phrase("Дайте, пожалуйста, чек.","Iltimos, chek bering.","Dayte pazhalusta chek"), Phrase("Когда будет в наличии?","Qachon mavjud bo‘ladi?","Kagda budet v nalichii"), Phrase("Можно обменять товар?","Mahsulotni almashtirish mumkinmi?","Mozhna obmenyat tovar"), Phrase("Сколько стоит доставка?","Yetkazib berish qancha turadi?","Skolka stoit dastavka"), Phrase("У меня возникла проблема.","Menda muammo yuzaga keldi.","U menya vaznikla problema"))),
    Triple("Transport va manzil", listOf(LessonSpec("Manzil so‘rash", "Manzilni so‘rash va tushunish"), LessonSpec("Taksi chaqirish", "Haydovchiga manzil aytish"), LessonSpec("Yo‘l yo‘nalishi", "Qanday borishni so‘rash"), LessonSpec("Masofa va vaqt", "Yo‘l qancha davom etishini bilish"), LessonSpec("Jamoat transporti", "Avtobus va metro haqida so‘rash"), LessonSpec("Kechikish", "Kechikayotganingizni aytish"), LessonSpec("Uchrashuv joyi", "Uchrashuv joyini kelishish"), LessonSpec("Joyni topolmaslik", "Yordam so‘rash"), LessonSpec("Chipta xarid qilish", "Chipta haqida savol berish"), LessonSpec("Xavfsiz yetib borish", "Yetib kelganingizni xabar qilish")), listOf(Phrase("Как пройти к этому адресу?","Bu manzilga qanday borsam bo‘ladi?","Kak proyti k etomu adresu"), Phrase("Отвезите меня, пожалуйста, сюда.","Iltimos, meni shu yerga olib boring.","Atvezite menya syuda"), Phrase("Поверните направо.","O‘ngga buriling.","Pavernite naprava"), Phrase("Сколько времени займёт дорога?","Yo‘l qancha vaqt oladi?","Skolka vremeni zaymyot daroga"), Phrase("Где ближайшая остановка?","Eng yaqin bekat qayerda?","Gde blizhayshaya astanovka"), Phrase("Я немного опаздываю.","Men biroz kechikyapman.","Ya nemnoga apazdyvayu"), Phrase("Давайте встретимся здесь.","Keling, shu yerda uchrashamiz.","Davayte vstretimsya zdes"), Phrase("Я не могу найти это место.","Bu joyni topa olmayapman.","Ya ne mogu nayti eta mesto"), Phrase("Где можно купить билет?","Chiptani qayerdan sotib olish mumkin?","Gde mozhna kupit bilet"), Phrase("Я уже приехал.","Men yetib keldim.","Ya uzhe priyekhal"))),
    Triple("Telefon va yozishmalar", listOf(LessonSpec("Telefon orqali salomlashish", "Qo‘ng‘iroqni to‘g‘ri boshlash"), LessonSpec("Kim bilan gaplashish", "Kerakli odamni so‘rash"), LessonSpec("Qayta qo‘ng‘iroq", "Keyinroq bog‘lanishni kelishish"), LessonSpec("Xabar yuborish", "Xabar yuborilganini aytish"), LessonSpec("Fayl va rasm yuborish", "Hujjat yoki surat yuborish"), LessonSpec("Ovoz eshitilmasligi", "Aloqa muammosini tushuntirish"), LessonSpec("Uchrashuvni tasdiqlash", "Uchrashuvni tasdiqlash"), LessonSpec("Eslatma yuborish", "Muloyim eslatma berish"), LessonSpec("Javob kutish", "Javob qachon bo‘lishini so‘rash"), LessonSpec("Aloqani saqlash", "Keyingi aloqani kelishish")), listOf(Phrase("Алло, добрый день!","Allo, xayrli kun!","Allo dobryy den"), Phrase("Можно поговорить с менеджером?","Menejer bilan gaplashsam bo‘ladimi?","Mozhna pagavarit s menedzherom"), Phrase("Я перезвоню вам позже.","Sizga keyinroq qayta qo‘ng‘iroq qilaman.","Ya perezvanyu vam pozhe"), Phrase("Я отправил вам сообщение.","Sizga xabar yubordim.","Ya otpravil vam saabsheniye"), Phrase("Сейчас отправлю фотографию.","Hozir surat yuboraman.","Seychas otpravlyu fotografiyu"), Phrase("Вас плохо слышно.","Sizni yaxshi eshitmayapman.","Vas plokho slyshno"), Phrase("Подтвердите, пожалуйста, встречу.","Iltimos, uchrashuvni tasdiqlang.","Patverdite pazhalusta vstrechu"), Phrase("Напоминаю о нашей встрече.","Uchrashuvimizni eslatib qo‘yyapman.","Napominayu a nashey vstreche"), Phrase("Когда ждать ваш ответ?","Javobingizni qachon kutsak bo‘ladi?","Kagda zhdat vash atvet"), Phrase("Будем на связи.","Aloqada bo‘lib turamiz.","Budem na svyazi"))),
    Triple("Ish va hamkasblar", listOf(LessonSpec("Ish joyida tanishish", "Hamkasb bilan tanishish"), LessonSpec("Vazifani tushunish", "Topshiriqni aniqlashtirish"), LessonSpec("Yordam so‘rash", "Ish bo‘yicha yordam so‘rash"), LessonSpec("Tayyorlik holati", "Ish holatini aytish"), LessonSpec("Ustuvorliklarni kelishish", "Muhim vazifani aniqlash"), LessonSpec("Uchrashuv tashkil qilish", "Yig‘ilish vaqtini kelishish"), LessonSpec("Fikr bildirish", "O‘z fikringizni aytish"), LessonSpec("Muammoni tushuntirish", "Muammoni xotirjam bayon qilish"), LessonSpec("Muddatni kelishish", "Ishni qachon tugatishni aytish"), LessonSpec("Hisobot berish", "Bajarilgan ish haqida xabar")), listOf(Phrase("Я новый сотрудник.","Men yangi xodimman.","Ya novyy sotrudnik"), Phrase("Что нужно сделать в первую очередь?","Avval nima qilish kerak?","Shto nuzhna sdelat v pervuyu ochered"), Phrase("Помогите мне, пожалуйста.","Iltimos, menga yordam bering.","Pamagite mne pazhalusta"), Phrase("Я уже занимаюсь этим.","Men bu ish bilan shug‘ullanyapman.","Ya uzhe zanimayus etim"), Phrase("Что сейчас самое важное?","Hozir eng muhim narsa nima?","Shto seychas samoye vazhnoye"), Phrase("Когда вам удобно встретиться?","Qachon uchrashish sizga qulay?","Kagda vam udobna vstretitsya"), Phrase("Я думаю, это хороший вариант.","Menimcha, bu yaxshi variant.","Ya dumayu eta kharoshiy variant"), Phrase("У нас возникла небольшая проблема.","Bizda kichik muammo yuzaga keldi.","U nas vaznikla nebolshaya problema"), Phrase("Я закончу работу к вечеру.","Ishni kechgacha tugataman.","Ya zakonchu rabotu k vecheru"), Phrase("Задача выполнена.","Vazifa bajarildi.","Zadacha vypolnena"))),
    Triple("Mijoz ehtiyojini aniqlash", listOf(LessonSpec("Buyurtma turini aniqlash", "Mijozga kerakli xizmatni tushunish"), LessonSpec("Joy va foydalanish", "Mahsulot qayerda ishlatilishini so‘rash"), LessonSpec("O‘lchamlar", "Eni va balandligini aniqlash"), LessonSpec("Material tanlash", "Material bo‘yicha savol berish"), LessonSpec("Dizayn va maket", "Dizayn tayyorligini aniqlash"), LessonSpec("Yoritish turi", "Yoritish kerakligini so‘rash"), LessonSpec("Rang va shrift", "Dizayn detallarini kelishish"), LessonSpec("Montaj shartlari", "O‘rnatish joyini aniqlash"), LessonSpec("Byudjetni aniqlash", "Mijozning taxminiy byudjetini so‘rash"), LessonSpec("Talablarni tasdiqlash", "Buyurtma tafsilotlarini takrorlash")), listOf(Phrase("Какой вид рекламы вам нужен?","Sizga qanday reklama turi kerak?","Kakoy vid reklamy vam nuzhen"), Phrase("Где будет размещена реклама?","Reklama qayerga joylashtiriladi?","Gde budet razmeshchena reklama"), Phrase("Какие размеры вам нужны?","Sizga qanday o‘lchamlar kerak?","Kakiye razmery vam nuzhny"), Phrase("Из какого материала будем делать?","Qaysi materialdan tayyorlaymiz?","Iz kakovo materiala budem delat"), Phrase("У вас уже есть макет?","Sizda maket tayyormi?","U vas uzhe yest maket"), Phrase("Вам нужна подсветка?","Sizga yoritish kerakmi?","Vam nuzhna podsvetka"), Phrase("Какой цвет и шрифт предпочитаете?","Qaysi rang va shriftni ma’qul ko‘rasiz?","Kakoy tsvet i shrift predpochitayete"), Phrase("Нужно ли установить конструкцию?","Konstruksiyani o‘rnatish kerakmi?","Nuzhna li ustanovit konstruktsiyu"), Phrase("На какой бюджет вы рассчитываете?","Qanday byudjetni mo‘ljallayapsiz?","Na kakoy byudzhet vy rasschityvayete"), Phrase("Давайте уточним все детали заказа.","Keling, buyurtmaning barcha tafsilotlarini aniqlashtiramiz.","Davayte utochnim vse detali zakaza"))),
    Triple("Narx, taklif va kelishuv", listOf(LessonSpec("Narx hisoblash", "Narxni hisoblashni tushuntirish"), LessonSpec("Narxga ta’sir qiluvchi omillar", "Narx nima sababdan o‘zgarishini aytish"), LessonSpec("Tijoriy taklif yuborish", "Taklifni yuborishni aytish"), LessonSpec("Chegirma haqida", "Chegirma shartlarini muhokama qilish"), LessonSpec("Oldindan to‘lov", "Avans haqida gaplashish"), LessonSpec("To‘lov muddatlari", "To‘lov vaqtini kelishish"), LessonSpec("Narxni asoslash", "Qiymat va sifatni tushuntirish"), LessonSpec("Variantlarni taqqoslash", "Bir necha variantni solishtirish"), LessonSpec("Taklifni tasdiqlash", "Mijozdan qaror so‘rash"), LessonSpec("Kelishuvni yakunlash", "Buyurtmani tasdiqlash")), listOf(Phrase("Я рассчитаю стоимость сегодня.","Narxini bugun hisoblab beraman.","Ya rasschitayu stoimost segodnya"), Phrase("Цена зависит от размера и материала.","Narx o‘lcham va materialga bog‘liq.","Tsena zavisit ot razmera i materiala"), Phrase("Я отправлю коммерческое предложение.","Tijoriy taklifni yuboraman.","Ya otpravlyu kommercheskoye predlozheniye"), Phrase("Для этого заказа возможна скидка.","Bu buyurtma uchun chegirma bo‘lishi mumkin.","Dlya etovo zakaza vazmozhna skidka"), Phrase("Для начала нужна предоплата.","Boshlash uchun oldindan to‘lov kerak.","Dlya nachala nuzhna predoplata"), Phrase("Когда вам удобно произвести оплату?","Qachon to‘lov qilish sizga qulay?","Kagda vam udobna proizvesti oplatu"), Phrase("Мы используем качественные материалы.","Biz sifatli materiallardan foydalanamiz.","My ispolzuyem kachestvennyye materialy"), Phrase("Могу предложить два варианта.","Sizga ikki variant taklif qila olaman.","Mogu predlozhit dva varianta"), Phrase("Какой вариант вам подходит?","Qaysi variant sizga mos keladi?","Kakoy variant vam podkhodit"), Phrase("Подтверждаем заказ?","Buyurtmani tasdiqlaymizmi?","Padtverzhdayem zakaz"))),
    Triple("Ishlab chiqarish va muddatlar", listOf(LessonSpec("Ishlab chiqarish jarayoni", "Tayyorlash bosqichlarini aytish"), LessonSpec("Muddatni aytish", "Tayyor bo‘lish vaqtini tushuntirish"), LessonSpec("Maketni tasdiqlash", "Maket tasdiqlanishini so‘rash"), LessonSpec("Material kelishi", "Material holati haqida xabar berish"), LessonSpec("Ish jarayoni yangiligi", "Buyurtma holatini aytish"), LessonSpec("Kechikish haqida ogohlantirish", "Kechikishni xushmuomala tushuntirish"), LessonSpec("Sifat nazorati", "Tekshiruv haqida xabar berish"), LessonSpec("Tayyor mahsulot", "Mahsulot tayyorligini aytish"), LessonSpec("Yetkazish va montaj", "O‘rnatish vaqtini kelishish"), LessonSpec("Topshirish va qabul qilish", "Buyurtmani qabul qilishni tasdiqlash")), listOf(Phrase("Мы уже начали изготовление.","Tayyorlashni boshlab yubordik.","My uzhe nachali izgotovleniye"), Phrase("Заказ будет готов через три дня.","Buyurtma uch kundan keyin tayyor bo‘ladi.","Zakaz budet gotov cherez tri dnya"), Phrase("Пожалуйста, утвердите макет.","Iltimos, maketni tasdiqlang.","Pazhalusta utverdite maket"), Phrase("Материалы уже поступили.","Materiallar allaqachon keldi.","Materialy uzhe postupili"), Phrase("Ваш заказ находится в работе.","Buyurtmangiz ishlab chiqarishda.","Vash zakaz nakhoditsya v rabote"), Phrase("Срок немного изменился.","Muddat biroz o‘zgardi.","Srok nemnoga izmenilsya"), Phrase("Мы проверяем качество изделия.","Mahsulot sifatini tekshiryapmiz.","My proveryayem kachestvo izdeliya"), Phrase("Ваш заказ уже готов.","Buyurtmangiz tayyor bo‘ldi.","Vash zakaz uzhe gotov"), Phrase("Когда удобно провести монтаж?","Montajni qachon qilish qulay?","Kagda udobna provesti montazh"), Phrase("Проверьте, пожалуйста, готовую работу.","Iltimos, tayyor ishni tekshiring.","Proverte pazhalusta gotovuyu rabotu"))),
    Triple("Mijoz bilan murakkab vaziyatlar", listOf(LessonSpec("Mijoz e’tirozini tinglash", "E’tirozni xotirjam qabul qilish"), LessonSpec("Narx qimmat deyishsa", "Narxni muloyim izohlash"), LessonSpec("Shoshilinch buyurtma", "Shoshilinch muddatni aniqlash"), LessonSpec("Xato uchun uzr", "Xatoni tan olib uzr aytish"), LessonSpec("Muqobil yechim", "Boshqa yechim taklif qilish"), LessonSpec("Mijoz javob bermasa", "Muloyim qayta aloqa qilish"), LessonSpec("Buyurtma o‘zgarishi", "O‘zgarishlarni aniqlashtirish"), LessonSpec("Noto‘g‘ri tushunishni tuzatish", "Tafsilotlarni qayta tekshirish"), LessonSpec("Shikoyatni hal qilish", "Yechim va keyingi qadamni aytish"), LessonSpec("Mijoz ishonchini saqlash", "Ishonchli va hurmatli javob berish")), listOf(Phrase("Я вас понимаю.","Sizni tushunaman.","Ya vas panimayu"), Phrase("Давайте посмотрим, что можно сделать.","Keling, nima qilish mumkinligini ko‘rib chiqamiz.","Davayte pasmotrim shto mozhna sdelat"), Phrase("Уточните, пожалуйста, желаемый срок.","Iltimos, kerakli muddatni aniqlashtiring.","Utochnite pazhalusta zhelayemyy srok"), Phrase("Приношу извинения за неудобства.","Noqulaylik uchun uzr so‘rayman.","Prinoshu izvineniya za neudobstva"), Phrase("Я могу предложить другой вариант.","Boshqa variant taklif qila olaman.","Ya mogu predlozhit drugoy variant"), Phrase("Хотел уточнить, актуален ли ещё заказ.","Buyurtma hali ham dolzarbmi, aniqlashtirmoqchi edim.","Khotel utochnit aktualen li yeshchyo zakaz"), Phrase("Что именно нужно изменить?","Aynan nimani o‘zgartirish kerak?","Shto imenno nuzhna izmenit"), Phrase("Давайте ещё раз проверим детали.","Keling, tafsilotlarni yana bir bor tekshiramiz.","Davayte yeshchyo raz proverim detali"), Phrase("Мы постараемся решить вопрос сегодня.","Masalani bugun hal qilishga harakat qilamiz.","My postarayemsya reshit vapros segodnya"), Phrase("Спасибо за ваше терпение.","Sabringiz uchun rahmat.","Spasiba za vashe terpeniye"))),
    Triple("Erkin gapirish va takrorlash", listOf(LessonSpec("O‘z fikrini aytish", "Oddiy fikrni ruscha ifodalash"), LessonSpec("Sabab tushuntirish", "Sababni sodda tushuntirish"), LessonSpec("Reja haqida gapirish", "Yaqin reja haqida aytish"), LessonSpec("O‘tgan ish haqida", "Bajarilgan ishni aytish"), LessonSpec("Kelajakdagi reja", "Keyingi qadamni aytish"), LessonSpec("Taqqoslash", "Variantlarni taqqoslash"), LessonSpec("Rozilik bildirish", "Rozilik yoki muloyim rad aytish"), LessonSpec("Aniqlik kiritish", "Gapni tushunarli qilish"), LessonSpec("Kichik hikoya", "Bir necha gap bilan bayon qilish"), LessonSpec("Yakuniy suhbat sinovi", "O‘rgangan iboralarni suhbatda qo‘llash")), listOf(Phrase("Я думаю, что это удобно.","Menimcha, bu qulay.","Ya dumayu shto eta udobna"), Phrase("Потому что это важно.","Chunki bu muhim.","Patamu shto eta vazhna"), Phrase("Завтра я позвоню клиенту.","Ertaga mijozga qo‘ng‘iroq qilaman.","Zavtra ya pazvanyu kliyentu"), Phrase("Вчера мы обсудили заказ.","Kecha buyurtmani muhokama qildik.","Vchera my obsudili zakaz"), Phrase("Следующий шаг — утвердить макет.","Keyingi qadam — maketni tasdiqlash.","Sleduyushchiy shag utverdit maket"), Phrase("Этот вариант дешевле, а тот быстрее.","Bu variant arzonroq, u esa tezroq.","Etot variant deshevle a tot bystreye"), Phrase("Я согласен с вами.","Men sizga qo‘shilaman.","Ya saglasen s vami"), Phrase("Я имею в виду размер вывески.","Men peshlavha o‘lchamini nazarda tutyapman.","Ya imeyu v vidu razmer vyveski"), Phrase("Сначала мы обсудили дизайн, потом цену.","Avval dizaynni, keyin narxni muhokama qildik.","Snachala my obsudili dizayn patom tsenu"), Phrase("Давайте подведём итог.","Keling, yakunlab olaylik.","Davayte padvedyom itog")))
)

private val commonPhraseBank = listOf(
    Phrase("Как я могу вам помочь?", "Sizga qanday yordam bera olaman?", "Kak ya mogu vam pamoch"),
    Phrase("Не могли бы вы уточнить?", "Aniqlashtirib bera olasizmi?", "Ne magli by vy utochnit"),
    Phrase("Я правильно понял?", "Men to‘g‘ri tushundimmi?", "Ya pravilna ponyal"),
    Phrase("Давайте обсудим подробнее.", "Keling, batafsil muhokama qilamiz.", "Davayte absudim padrobneye"),
    Phrase("Мне нужно немного времени.", "Menga biroz vaqt kerak.", "Mne nuzhna nemnoga vremeni"),
    Phrase("Я уточню и сообщу вам.", "Aniqlashtirib, sizga xabar beraman.", "Ya utochnyu i saabshu vam"),
    Phrase("Это возможно.", "Buni amalga oshirish mumkin.", "Eta vazmozhna"),
    Phrase("К сожалению, сейчас нет.", "Afsuski, hozir yo‘q.", "K sazhaleniyu seychas nyet"),
    Phrase("Есть ли у вас вопросы?", "Savollaringiz bormi?", "Yest li u vas vaprosy"),
    Phrase("Спасибо за ожидание.", "Kutinganingiz uchun rahmat.", "Spasiba za azhidaniye"),
    Phrase("Я вас внимательно слушаю.", "Sizni diqqat bilan tinglayapman.", "Ya vas vnimatelna slushayu"),
    Phrase("Можете объяснить ещё раз?", "Yana bir bor tushuntira olasizmi?", "Mozhete abyasnit yeshchyo raz"),
    Phrase("Я проверю эту информацию.", "Bu ma’lumotni tekshiraman.", "Ya proverу etu informatsiyu"),
    Phrase("Договорились.", "Kelishdik.", "Dagavarilis"),
    Phrase("Это подходит.", "Bu mos keladi.", "Eta padkhodit"),
    Phrase("Мне нужно согласовать детали.", "Tafsilotlarni kelishib olishim kerak.", "Mne nuzhna saglasavat detali"),
    Phrase("Когда вам будет удобно?", "Qachon sizga qulay bo‘ladi?", "Kagda vam budet udobna"),
    Phrase("Я скоро вернусь с ответом.", "Tez orada javob bilan qaytaman.", "Ya skoro vernus s atvetam"),
    Phrase("Хорошо, я вас понял.", "Yaxshi, sizni tushundim.", "Kharasho ya vas ponyal"),
    Phrase("Спасибо за сотрудничество.", "Hamkorligingiz uchun rahmat.", "Spasiba za sotrudnichestvo")
)

private val lessons: List<Lesson> = moduleData.flatMapIndexed { moduleIndex, data ->
    val moduleNumber = moduleIndex + 1
    val moduleTitle = data.first
    val specs = data.second
    val phraseBank = data.third
    specs.mapIndexed { lessonIndex, spec ->
        val offset = (lessonIndex * 2) % phraseBank.size
        val lessonPhrases = (0 until 30).map { i ->
            if (i < 10) phraseBank[(offset + i) % phraseBank.size]
            else commonPhraseBank[(i - 10 + lessonIndex) % commonPhraseBank.size]
        }
        val dialogues = buildList {
            // Dialog 1: greet a customer and clarify the request (8 turns)
            add(DialogueLine("1-dialog · Mijoz", "Здравствуйте! Мне нужна вывеска для магазина.", "Assalomu alaykum! Menga do‘kon uchun peshlavha kerak."))
            add(DialogueLine("1-dialog · Siz", "Добрый день! Конечно, поможем. Как называется ваш магазин?", "Xayrli kun! Albatta, yordam beramiz. Do‘koningizning nomi nima?"))
            add(DialogueLine("1-dialog · Mijoz", "Магазин называется «Амина».", "Do‘kon «Amina» deb nomlanadi."))
            add(DialogueLine("1-dialog · Siz", "Понял. Какой размер вывески вам нужен?", "Tushundim. Sizga qanday o‘lchamdagi peshlavha kerak?"))
            add(DialogueLine("1-dialog · Mijoz", "Примерно три метра в длину и восемьдесят сантиметров в высоту.", "Taxminan uzunligi uch metr, balandligi sakson santimetr."))
            add(DialogueLine("1-dialog · Siz", "Вам нужна подсветка?", "Sizga yoritish kerakmi?"))
            add(DialogueLine("1-dialog · Mijoz", "Да, желательно, чтобы буквы светились.", "Ha, harflar yonib turishi ma’qul."))
            add(DialogueLine("1-dialog · Siz", "Хорошо. Я уточню детали и подготовлю расчёт стоимости.", "Yaxshi. Tafsilotlarni aniqlashtirib, narx hisobini tayyorlayman."))

            // Dialog 2: discuss price and quotation (8 turns)
            add(DialogueLine("2-dialog · Siz", "Я подготовил расчёт и отправляю вам коммерческое предложение.", "Hisob-kitobni tayyorladim va sizga tijoriy taklifni yuboryapman."))
            add(DialogueLine("2-dialog · Mijoz", "Спасибо. Почему цена немного выше, чем я ожидал?", "Rahmat. Nega narx men kutganimdan biroz yuqori?"))
            add(DialogueLine("2-dialog · Siz", "В стоимость входят материалы, световые модули и монтаж.", "Narxga materiallar, yoritish modullari va montaj kiradi."))
            add(DialogueLine("2-dialog · Mijoz", "Можно сделать дешевле?", "Arzonroq qilish mumkinmi?"))
            add(DialogueLine("2-dialog · Siz", "Да, можем рассмотреть другой материал или вариант без монтажа.", "Ha, boshqa material yoki montajsiz variantni ko‘rib chiqishimiz mumkin."))
            add(DialogueLine("2-dialog · Mijoz", "А качество и срок службы будут такими же?", "Sifati va xizmat muddati ham xuddi shunday bo‘ladimi?"))
            add(DialogueLine("2-dialog · Siz", "Я объясню разницу между вариантами и укажу её в предложении.", "Variantlar o‘rtasidagi farqni tushuntirib, taklifda ko‘rsataman."))
            add(DialogueLine("2-dialog · Mijoz", "Хорошо, отправьте мне оба варианта, пожалуйста.", "Yaxshi, iltimos, ikkala variantni ham yuboring."))

            // Dialog 3: approve design, deadline and order (8 turns)
            add(DialogueLine("3-dialog · Siz", "Макет готов. Посмотрите, пожалуйста, и подтвердите его.", "Maket tayyor. Iltimos, ko‘rib chiqing va tasdiqlang."))
            add(DialogueLine("3-dialog · Mijoz", "В целом всё хорошо, но можно изменить цвет букв?", "Umuman olganda, hammasi yaxshi, lekin harflar rangini o‘zgartirish mumkinmi?"))
            add(DialogueLine("3-dialog · Siz", "Конечно. Какой цвет вы предпочитаете?", "Albatta. Qaysi rangni ma’qul ko‘rasiz?"))
            add(DialogueLine("3-dialog · Mijoz", "Давайте сделаем золотой цвет.", "Keling, tilla rang qilaylik."))
            add(DialogueLine("3-dialog · Siz", "Хорошо, внесём изменение и отправим обновлённый макет сегодня.", "Yaxshi, o‘zgarishni kiritib, yangilangan maketni bugun yuboramiz."))
            add(DialogueLine("3-dialog · Mijoz", "Сколько времени займёт изготовление после утверждения?", "Tasdiqlangandan keyin tayyorlash qancha vaqt oladi?"))
            add(DialogueLine("3-dialog · Siz", "Обычно пять рабочих дней после согласования и предоплаты.", "Odatda kelishuv va oldindan to‘lovdan keyin besh ish kuni."))
            add(DialogueLine("3-dialog · Mijoz", "Отлично, подтверждаю заказ. Спасибо!", "Ajoyib, buyurtmani tasdiqlayman. Rahmat!"))
        }
        val exercises = (0 until 15).map { i ->
            val correctPhrase = lessonPhrases[i % lessonPhrases.size]
            val distractor1 = lessonPhrases[(i + 7) % lessonPhrases.size]
            val distractor2 = lessonPhrases[(i + 13) % lessonPhrases.size]
            val answers = listOf(correctPhrase.ru, distractor1.ru, distractor2.ru).shuffled(java.util.Random(i.toLong() + lessonIndex * 100L + moduleIndex * 1000L))
            Exercise("${i + 1}/15. “${correctPhrase.uz}” iborasining ruschasini tanlang.", answers, answers.indexOf(correctPhrase.ru), "${correctPhrase.ru} — ${correctPhrase.uz}")
        }
        Lesson("m${moduleNumber}l${lessonIndex + 1}", moduleNumber, moduleTitle, spec.title, spec.goal, lessonPhrases, dialogues, exercises)
    }
}



@Composable
fun RusUstozApp() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    var selectedLessonId by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val progressPrefs = remember { context.getSharedPreferences("rusustoz_pro_progress", android.content.Context.MODE_PRIVATE) }
    val completed = remember { mutableStateListOf<String>().apply { addAll(progressPrefs.getStringSet("completed_lessons", emptySet()) ?: emptySet()) } }
    Scaffold(bottomBar = {
        NavigationBar { Tab.entries.forEach { tab ->
            NavigationBarItem(selected = current == tab.route, onClick = {
                nav.navigate(tab.route) { popUpTo(nav.graph.findStartDestination().id) { saveState = true }; launchSingleTop = true; restoreState = true }
            }, icon = { Icon(tab.icon, contentDescription = tab.label) }, label = { Text(tab.label) })
        } }
    }) { padding ->
        NavHost(nav, startDestination = Tab.Home.route, modifier = Modifier.padding(padding)) {
            composable(Tab.Home.route) { HomeScreen(completed.size, lessons.size, onLessons = { nav.navigate(Tab.Lessons.route) }) }
            composable(Tab.Lessons.route) {
                val selected = lessons.firstOrNull { it.id == selectedLessonId }
                if (selected == null) LessonsScreen(completed, onOpen = { selectedLessonId = it })
                else LessonScreen(selected, selected.id in completed, onBack = { selectedLessonId = null }, onComplete = { if (selected.id !in completed) { completed.add(selected.id); progressPrefs.edit().putStringSet("completed_lessons", completed.toSet()).apply() } })
            }
            composable(Tab.Teacher.route) { TeacherScreen() }
            composable(Tab.Words.route) { VocabularyScreen() }
            composable(Tab.Profile.route) { ProfileScreen(completed.size, lessons.size) }
        }
    }
}

@Composable private fun HomeScreen(done: Int, total: Int, onLessons: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("RusUstoz", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Rus tilida ishonch bilan gapirishni boshlang.", style = MaterialTheme.typography.bodyLarge)
        Card { Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Sizning o‘rganish yo‘lingiz", style = MaterialTheme.typography.titleMedium)
            Text("$done / $total dars tugallangan")
            LinearProgressIndicator(progress = if (total == 0) 0f else done.toFloat()/total, modifier = Modifier.fillMaxWidth())
            Button(onClick = onLessons, modifier = Modifier.fillMaxWidth()) { Text("Darsni boshlash") }
        } }
        Text("Bugungi maqsad", style = MaterialTheme.typography.titleMedium)
        Text("Kuniga 30 daqiqa: iboralarni o‘qing, talaffuzni tinglang va kichik testni bajaring.")
        Text("Yangi versiya: 10 modul · 100 dars · kundalik va ish suhbatlari", style = MaterialTheme.typography.labelLarge)
    }
}

@Composable private fun LessonsScreen(completed: List<String>, onOpen: (String) -> Unit) {
    var expandedModule by remember { mutableIntStateOf(1) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("O‘quv dasturi", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(4.dp))
            Text("10 modul · 100 dars · bosqichma-bosqich", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = if (lessons.isEmpty()) 0f else completed.size.toFloat() / lessons.size, modifier = Modifier.fillMaxWidth())
            Text("${completed.size} / ${lessons.size} dars bajarildi", style = MaterialTheme.typography.labelMedium)
        }
        moduleData.forEachIndexed { index, data ->
            val moduleNo = index + 1
            val moduleLessons = lessons.filter { it.module == moduleNo }
            val moduleDone = moduleLessons.count { it.id in completed }
            item(key = "module_$moduleNo") {
                Card(Modifier.fillMaxWidth().clickable { expandedModule = if (expandedModule == moduleNo) 0 else moduleNo }, colors = CardDefaults.cardColors(containerColor = if (expandedModule == moduleNo) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${moduleNo.toString().padStart(2, '0')}  ·  MODUL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text(data.first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("$moduleDone / ${moduleLessons.size} dars", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                            LinearProgressIndicator(progress = if (moduleLessons.isEmpty()) 0f else moduleDone.toFloat() / moduleLessons.size, modifier = Modifier.fillMaxWidth())
                        }
                        Icon(if (expandedModule == moduleNo) Icons.Filled.ExpandMore else Icons.Filled.ChevronRight, contentDescription = "Modulni ochish")
                    }
                }
            }
            if (expandedModule == moduleNo) {
                items(moduleLessons, key = { it.id }) { lesson -> LessonCard(lesson, lesson.id in completed, onOpen) }
            }
        }
    }
}

@Composable private fun LessonCard(lesson: Lesson, done: Boolean, onOpen: (String) -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onOpen(lesson.id) }) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(lesson.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text(lesson.goal, style = MaterialTheme.typography.bodySmall) }
        Text(if (done) "✓ Bajarildi" else "Boshlash", color = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.labelMedium)
    } }
}

@Composable private fun LessonScreen(lesson: Lesson, done: Boolean, onBack: () -> Unit, onComplete: () -> Unit) {
    var answers by remember(lesson.id) { mutableStateOf(mapOf<Int, Int>()) }
    val context = LocalContext.current
    val tts = remember { TextToSpeech(context) { status -> if (status == TextToSpeech.SUCCESS) { /* language is selected when Speak is pressed */ } } }
    DisposableEffect(tts) { onDispose { tts.stop(); tts.shutdown() } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("‹ Orqaga", Modifier.clickable { onBack() }.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.primary) }
        item { Text("${lesson.module}-modul · ${lesson.moduleTitle}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary) }
        item { Text(lesson.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text(lesson.goal, style = MaterialTheme.typography.bodyLarge) }
        item { Text("Asosiy iboralar", style = MaterialTheme.typography.titleLarge) }
        items(lesson.phrases) { p -> Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(p.ru, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(p.uz)
            Text("Talaffuz: ${p.pron}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            TextButton(onClick = { val result = tts.setLanguage(Locale("ru", "RU")); if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) tts.speak(p.ru, TextToSpeech.QUEUE_FLUSH, null, p.ru) }) { Text("🔊 Tinglash") }
        } } }
        item { Text("3 ta amaliy dialog", style = MaterialTheme.typography.titleLarge) }
        items(lesson.dialogue) { line -> Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(line.speaker, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary); Text(line.ru, fontWeight = FontWeight.SemiBold); Text(line.uz) } } }
        item { Text("15 ta mashq", style = MaterialTheme.typography.titleLarge) }
        items(lesson.exercises.size) { exerciseIndex ->
            val exercise = lesson.exercises[exerciseIndex]
            Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(exercise.question, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                exercise.answers.forEachIndexed { answerIndex, option ->
                    OutlinedButton(onClick = { answers = answers + (exerciseIndex to answerIndex) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (answers[exerciseIndex] == answerIndex) { if (answerIndex == exercise.correct) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer } else MaterialTheme.colorScheme.surface)) { Text(option) }
                }
                if (answers.containsKey(exerciseIndex)) Text(if (answers[exerciseIndex] == exercise.correct) "To‘g‘ri! ${exercise.explanation}" else "Qayta urinib ko‘ring. ${exercise.explanation}", color = if (answers[exerciseIndex] == exercise.correct) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            } }
        }
        item { Button(onClick = { if (lesson.exercises.indices.all { answers[it] == lesson.exercises[it].correct }) onComplete() }, enabled = lesson.exercises.indices.all { answers[it] == lesson.exercises[it].correct }, modifier = Modifier.fillMaxWidth()) { Text(if (done) "Dars bajarilgan ✓" else "Barcha 15 mashqni to‘g‘ri bajaring") } }
    }
}

@Composable private fun VocabularyScreen() {
    val words = listOf("Здравствуйте!" to "Assalomu alaykum!", "Чем могу помочь?" to "Sizga qanday yordam bera olaman?", "У вас есть макет?" to "Sizda maket bormi?", "Нужна подсветка?" to "Yoritish kerakmi?", "Стоимость" to "Narx / qiymat", "Размер" to "O‘lcham", "Изготовление" to "Tayyorlash / ishlab chiqarish", "Я отправлю вам расчёт." to "Sizga hisob-kitobni yuboraman.", "Спасибо большое." to "Katta rahmat.", "Хорошего дня!" to "Kuningiz yaxshi o‘tsin!")
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Lug‘at", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Ishda tez-tez ishlatiladigan iboralar") }
        items(words) { (ru,uz) -> Card { Column(Modifier.fillMaxWidth().padding(14.dp)) { Text(ru, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text(uz) } } }
    }
}

@Composable private fun TeacherScreen() {
    var message by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(false) }
    var recognized by remember { mutableStateOf("") }
    val context = LocalContext.current
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            recognized = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (recognized.isNotBlank()) message = recognized
            sent = false
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Rus tilida gapiring")
            }
            try { speechLauncher.launch(intent) } catch (_: Exception) { recognized = "Telefoningizda ovozli tanish funksiyasi mavjud emas." }
        } else recognized = "Mikrofondan foydalanish uchun ruxsat kerak."
    }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("AI Ustoz", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Bu sinov rejimi. Hozircha haqiqiy AI serveriga ulanmagan.")
        Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Ustoz: Добрый день! Чем могу помочь?", fontWeight = FontWeight.SemiBold)
            Text("Tarjimasi: Xayrli kun! Sizga qanday yordam bera olaman?")
            OutlinedTextField(value = message, onValueChange = { message = it; sent = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Rus tilida javob yozing yoki ayting") })
            OutlinedButton(onClick = {
                if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Rus tilida gapiring")
                    }
                    try { speechLauncher.launch(intent) } catch (_: Exception) { recognized = "Ovozli tanish xizmati topilmadi." }
                } else permissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
            }, modifier = Modifier.fillMaxWidth()) { Text("🎙 Mikrofon orqali javob berish") }
            if (recognized.isNotBlank()) Text("Ovozdan tanilgan matn: $recognized", style = MaterialTheme.typography.bodySmall)
            Button(onClick = { sent = true }, enabled = message.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Javobni tekshirish") }
            if (sent) Text(if (message.contains("нуж", ignoreCase = true) || message.contains("вывес", ignoreCase = true) || message.contains("мне", ignoreCase = true)) "Yaxshi! Javobingiz ruscha iboralarni ishlatishga urinadi. Hozircha baholash oddiy kalit-so‘zlar bilan ishlaydi, to‘liq AI emas." else "Javob qabul qilindi. Bu versiyada avtomatik tekshiruv oddiy kalit-so‘zlar asosida ishlaydi.")
        } }
    }
}

@Composable private fun ProfileScreen(done: Int, total: Int) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Profil", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("O‘quvchi")
        Text("Bajarilgan darslar: $done / $total")
        LinearProgressIndicator(progress = if (total == 0) 0f else done.toFloat()/total, modifier = Modifier.fillMaxWidth())
        Text("Maqsad: har kuni 30 daqiqa rus tilida mashq qilish.")
        Text("Eslatma: bu dastlabki versiyada dars progressi ilova ochiq turgan vaqt davomida saqlanadi. Doimiy saqlash keyingi bosqichda qo‘shiladi.", style = MaterialTheme.typography.bodySmall)
    }
}
