package uz.rusustoz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import uz.rusustoz.app.ui.RusUstozApp
import uz.rusustoz.app.ui.theme.RusUstozTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RusUstozTheme {
                RusUstozApp()
            }
        }
    }
}
